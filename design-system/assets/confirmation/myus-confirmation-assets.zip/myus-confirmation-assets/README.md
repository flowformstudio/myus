# MyUS Confirmation Page — Asset Kit

All assets used by the registration confirmation page (confirmation.html).
Also available as export-ready components in Figma → "🧰 Confirmation Assets" page.

## icons/  (SVG unless noted)
- conf-hero-check.svg     — approved hero (animated in code: confetti burst + pop)
- conf-hero-pending.svg   — pending hero clock (static; live version uses inline SVG with rotating hands)
- conf-hero-stop.png      — rejected hero (animated in code: one-shot deny shake) · 400px, transparent
- conf-step-filecheck.svg / conf-step-filesearch.svg / conf-step-inbox.svg — "What happens next?" stepper
- conf-faq-chevron.svg    — FAQ accordion
- conf-flag-us.png / conf-flag-uk.png — address cards · 168px (4x), circular alpha
- conf-info-circle.svg    — legacy alert icon (superseded by the stepper card)

## images/
- member-invite/family/shopping.png — membership photo cards (683×1024)

## Motion specs (implemented in confirmation.html)
- Confetti: 30 pieces, DS palette; power 3.4–6.6, gravity 0.085/frame(60fps), drag 0.972x/0.992y,
  sine sway; life 2.4s; dissolves 55–130px below icon; repeats after 5s pause; click to replay.
- Clock: minute hand 360°/6s, hour hand 360°/72s, linear infinite, origin at face center.
- Deny shake: 0 → −5.5° → 4.5° → −2.5° → 1° → 0 over 1.15s, delay 0.4s,
  cubic-bezier(0.36,0.07,0.19,0.97), origin 50% 60%, plays once.
All animations honor prefers-reduced-motion.
